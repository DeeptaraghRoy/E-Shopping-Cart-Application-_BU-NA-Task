package com.capg.profileJWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
